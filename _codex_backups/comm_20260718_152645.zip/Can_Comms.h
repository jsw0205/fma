#ifndef CAN_COMMS_H
#define CAN_COMMS_H

#include "Ifx_Types.h"

#define CAN_DRIVE_STATUS_ID  0x102U
#define CAN_STEERING_STATUS_ID  0x101U
#define CAN_COMMAND_ID  0x200U

extern volatile uint32 g_canTxCount;
extern volatile uint32 g_canTxBusyCount;
extern volatile uint32 g_canRxCount;
extern volatile uint32 g_canInitStatus;
extern volatile uint32 g_canNodeInitStatus;
extern volatile uint32 g_canMsgObjInitStatus;
extern volatile uint32 g_canLastSendStatus;
extern volatile uint8 g_canLastPayload[8];
extern volatile sint16 g_canCmdTargetRpm;
extern volatile sint16 g_canCmdSteerAngle;
extern volatile boolean g_canCmdEnable;
extern volatile boolean g_canCmdActive;
extern volatile boolean g_canCmdSeen;
extern volatile boolean g_canCmdFlatStopMode;

void Can_Comms_Init(void);
void Can_Comms_Update_5ms(void);
void Can_Comms_SendDriveStatus(sint16 pwmDuty, sint16 targetRpm);
void Can_Comms_SendSteeringStatus(void);

#endif /* CAN_COMMS_H */
